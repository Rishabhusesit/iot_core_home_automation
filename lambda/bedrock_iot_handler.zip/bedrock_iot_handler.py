"""
AWS Lambda Function: IoT to Bedrock Integration
Processes IoT messages and invokes Bedrock for AI analysis
Publishes results back to IoT topic
"""
import json
import boto3
import os
from datetime import datetime

# Initialize AWS clients
iot_client = boto3.client('iot-data')
bedrock_runtime = boto3.client('bedrock-runtime')

# Configuration
BEDROCK_MODEL_ID = os.environ.get('BEDROCK_MODEL_ID', 'anthropic.claude-3-sonnet-20240229-v1:0')
RESPONSE_TOPIC = os.environ.get('RESPONSE_TOPIC', 'devices/ESP32_Device/ai_responses')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')

def lambda_handler(event, context):
    """
    Lambda handler for processing IoT messages
    
    Event structure:
    {
        "topic": "devices/ESP32_Device/data",
        "payload": {
            "device_id": "ESP32_Device",
            "timestamp": "...",
            "sensor_data": {...}
        }
    }
    """
    try:
        # Extract message data
        if 'topic' in event:
            topic = event['topic']
            payload = event.get('payload', {})
        else:
            # Direct payload (from IoT Rule)
            payload = event
            topic = payload.get('topic', 'unknown')
        
        # Extract sensor data
        sensor_data = payload.get('sensor_data', {})
        device_id = payload.get('device_id', 'unknown')
        
        print(f"Processing message from device: {device_id}")
        print(f"Sensor data: {json.dumps(sensor_data)}")
        
        # Create AI analysis prompt
        prompt = create_analysis_prompt(sensor_data)
        
        # Invoke Bedrock
        ai_response = invoke_bedrock(prompt)
        
        # Parse AI response
        analysis = parse_ai_response(ai_response)
        
        # Create response message
        response_message = {
            'device_id': device_id,
            'original_timestamp': payload.get('timestamp'),
            'analysis_timestamp': datetime.utcnow().isoformat(),
            'sensor_data': sensor_data,
            'ai_response': analysis,
            'model_used': BEDROCK_MODEL_ID
        }
        
        # Publish response to IoT topic
        publish_to_iot(RESPONSE_TOPIC, response_message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully processed and analyzed sensor data',
                'device_id': device_id,
                'analysis': analysis
            })
        }
        
    except Exception as e:
        print(f"Error processing message: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }

def create_analysis_prompt(sensor_data):
    """Create prompt for AI analysis"""
    temperature = sensor_data.get('temperature', 'N/A')
    humidity = sensor_data.get('humidity', 'N/A')
    pressure = sensor_data.get('pressure', 'N/A')
    
    prompt = f"""You are an IoT sensor data analyst. Analyze the following sensor readings and provide a concise JSON response.

Sensor Data:
- Temperature: {temperature}°C
- Humidity: {humidity}%
- Pressure: {pressure} hPa

Provide your analysis in this JSON format:
{{
  "assessment": "brief environmental assessment",
  "anomalies": ["any anomalies detected"],
  "recommendations": ["actionable recommendations"],
  "risk_level": "low|medium|high",
  "summary": "one sentence summary"
}}

Be concise and actionable."""
    
    return prompt

def invoke_bedrock(prompt):
    """Invoke AWS Bedrock model"""
    # Prepare request body for Claude
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 512,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }
    
    # Invoke model
    response = bedrock_runtime.invoke_model(
        modelId=BEDROCK_MODEL_ID,
        body=json.dumps(body)
    )
    
    # Parse response
    response_body = json.loads(response['body'].read())
    return response_body['content'][0]['text']

def parse_ai_response(ai_text):
    """Parse AI response text to extract JSON"""
    try:
        # Try to extract JSON from response
        # AI might wrap JSON in markdown code blocks
        if '```json' in ai_text:
            start = ai_text.find('```json') + 7
            end = ai_text.find('```', start)
            json_str = ai_text[start:end].strip()
        elif '```' in ai_text:
            start = ai_text.find('```') + 3
            end = ai_text.find('```', start)
            json_str = ai_text[start:end].strip()
        else:
            # Try to find JSON object
            start = ai_text.find('{')
            end = ai_text.rfind('}') + 1
            json_str = ai_text[start:end]
        
        return json.loads(json_str)
    except:
        # If parsing fails, return as text
        return {'raw_response': ai_text}

def publish_to_iot(topic, message):
    """Publish message to IoT topic"""
    iot_endpoint = os.environ.get('IOT_ENDPOINT')
    if not iot_endpoint:
        # Get endpoint from IoT Core
        iot = boto3.client('iot')
        response = iot.describe_endpoint(endpointType='iot:Data-ATS')
        iot_endpoint = response['endpointAddress']
    
    # Publish to IoT topic
    iot_client.publish(
        topic=topic,
        qos=1,
        payload=json.dumps(message)
    )
    
    print(f"Published response to topic: {topic}")


"""
Backend API Server for ESP32 IoT Dashboard
Provides REST API for web interface and manages IoT data
Includes Cognito authentication support
"""
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import boto3
import json
import os
import sys
from datetime import datetime, timedelta
from dotenv import load_dotenv
import threading
import time

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

app = Flask(__name__, 
            static_folder='../web', 
            static_url_path='/static',
            template_folder='../web')
CORS(app)

# Initialize Cognito auth (optional)
try:
    from auth.cognito_auth import CognitoAuth
    cognito_auth = CognitoAuth()
    AUTH_ENABLED = os.getenv('ENABLE_AUTH', 'false').lower() == 'true'
except ImportError:
    cognito_auth = None
    AUTH_ENABLED = False

# AWS IoT Core client
iot_client = boto3.client('iot-data', region_name=os.getenv('AWS_REGION', 'us-east-1'))
iot_endpoint = os.getenv('AWS_IOT_ENDPOINT', '')

# Device configuration
THING_NAME = os.getenv('THING_NAME', 'ESP32_SmartDevice')
COMMAND_TOPIC = f'devices/{THING_NAME}/commands'
DATA_TOPIC = f'devices/{THING_NAME}/data'
STATUS_TOPIC = f'devices/{THING_NAME}/status'
ALERTS_TOPIC = f'devices/{THING_NAME}/alerts'

# In-memory data store (in production, use database)
# This will be updated by iot_subscriber.py
try:
    from iot_subscriber import get_device_data
    device_data = get_device_data()
except:
    device_data = {
        'sensor_data': {},
        'relays': {},
        'status': 'offline',
        'last_update': None,
        'uptime_seconds': 0,
        'wifi_rssi': 0
    }

ai_insights = []

@app.route('/')
def index():
    """Serve dashboard HTML"""
    import os
    dashboard_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'web', 'dashboard.html')
    with open(dashboard_path, 'r') as f:
        return f.read()

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Authenticate user with Cognito"""
    if not AUTH_ENABLED or not cognito_auth:
        return jsonify({
            'success': False,
            'error': 'Authentication not enabled'
        }), 400
    
    try:
        data = request.json
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({
                'success': False,
                'error': 'Username and password required'
            }), 400
        
        result = cognito_auth.authenticate_user(username, password)
        
        if result['success']:
            return jsonify({
                'success': True,
                'access_token': result['access_token'],
                'id_token': result.get('id_token', ''),
                'expires_in': result['expires_in']
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 401
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/auth/verify', methods=['GET'])
def verify_token():
    """Verify access token"""
    if not AUTH_ENABLED or not cognito_auth:
        return jsonify({
            'success': False,
            'error': 'Authentication not enabled'
        }), 400
    
    auth_header = request.headers.get('Authorization', '')
    
    if not auth_header.startswith('Bearer '):
        return jsonify({
            'success': False,
            'error': 'Missing authorization header'
        }), 401
    
    token = auth_header.replace('Bearer ', '')
    result = cognito_auth.verify_token(token)
    
    if result['success']:
        return jsonify({
            'success': True,
            'username': result['username'],
            'user_attributes': result['user_attributes']
        })
    else:
        return jsonify({
            'success': False,
            'error': result['error']
        }), 401

@app.route('/api/device/status', methods=['GET'])
def get_device_status():
    """Get current device status and sensor data"""
    # Get latest data from IoT subscriber if available
    try:
        from iot_subscriber import get_device_data
        current_data = get_device_data()
        if current_data:
            device_data.update(current_data)
    except:
        pass
    
    return jsonify({
        'success': True,
        'device_id': THING_NAME,
        'status': device_data.get('status', 'offline'),
        'sensor_data': device_data.get('sensor_data', {}),
        'relays': device_data.get('relays', {}),
        'uptime_seconds': device_data.get('uptime_seconds', 0),
        'wifi_rssi': device_data.get('wifi_rssi', 0),
        'last_update': str(device_data.get('last_update')) if device_data.get('last_update') else None
    })

@app.route('/api/device/relay', methods=['POST'])
def control_relay():
    """Control relay via MQTT command"""
    try:
        data = request.json
        relay_num = data.get('relay')
        state = data.get('state')
        
        if not relay_num or state is None:
            return jsonify({'success': False, 'error': 'Missing relay or state'}), 400
        
        # Publish command to IoT Core
        command = {
            'command': 'relay_control',
            'relay': relay_num,
            'state': state,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        response = iot_client.publish(
            topic=COMMAND_TOPIC,
            qos=1,
            payload=json.dumps(command)
        )
        
        # Update local state
        if 'relays' not in device_data:
            device_data['relays'] = {}
        device_data['relays'][f'relay_{relay_num}'] = state
        
        return jsonify({
            'success': True,
            'message': f'Relay {relay_num} command sent',
            'relay': relay_num,
            'state': state
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/device/command', methods=['POST'])
def send_command():
    """Send custom command to device"""
    try:
        data = request.json
        command = data.get('command')
        
        if not command:
            return jsonify({'success': False, 'error': 'Missing command'}), 400
        
        mqtt_command = {
            'command': command,
            'timestamp': datetime.utcnow().isoformat(),
            **data.get('params', {})
        }
        
        response = iot_client.publish(
            topic=COMMAND_TOPIC,
            qos=1,
            payload=json.dumps(mqtt_command)
        )
        
        return jsonify({
            'success': True,
            'message': 'Command sent successfully'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ai/insights', methods=['GET'])
def get_ai_insights():
    """Get AI insights and recommendations"""
    return jsonify({
        'success': True,
        'insights': ai_insights
    })

@app.route('/api/data/history', methods=['GET'])
def get_data_history():
    """Get historical sensor data (mock - in production, query database)"""
    # In production, query DynamoDB or TimeStream
    return jsonify({
        'success': True,
        'data': [],
        'message': 'Historical data not implemented. Use AWS IoT Analytics or TimeStream.'
    })

@app.route('/api/device/alerts', methods=['GET'])
def get_alerts():
    """Get recent alerts"""
    # In production, query from database
    return jsonify({
        'success': True,
        'alerts': []
    })

# Simulate IoT message processing (in production, use IoT Rules → Lambda → API)
def process_iot_message():
    """Process incoming IoT messages (simulated)"""
    # In production, this would be triggered by IoT Rules → Lambda → API Gateway
    # or use IoT Core MQTT subscription
    pass

# Background thread to simulate data updates
def update_device_data():
    """Periodically update device data (simulated)"""
    while True:
        # In production, this would subscribe to IoT topics or query database
        # For now, we'll just mark as online if data exists
        if device_data.get('last_update'):
            time_diff = (datetime.utcnow() - device_data['last_update']).total_seconds()
            if time_diff < 30:  # Consider online if updated in last 30 seconds
                device_data['status'] = 'online'
            else:
                device_data['status'] = 'offline'
        
        time.sleep(5)

# Start background thread
threading.Thread(target=update_device_data, daemon=True).start()

if __name__ == '__main__':
    print("=" * 60)
    print("ESP32 IoT Backend API Server")
    print("=" * 60)
    print(f"Device: {THING_NAME}")
    print(f"IoT Endpoint: {iot_endpoint}")
    print(f"Command Topic: {COMMAND_TOPIC}")
    print("=" * 60)
    print("\nStarting server on http://localhost:5000")
    print("Dashboard: http://localhost:5000")
    print("\nPress Ctrl+C to stop\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

